import React, { useState } from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-gray-800 text-white p-4 shadow-lg">
      <div className="container mx-auto flex items-center justify-between">
        {/* Brand / Logo */}
        <Link
          to="/"
          className="text-2xl md:text-3xl font-extrabold text-white drop-shadow-lg font-serif"
        >
          🌿 Echoes of Jharkhand
        </Link>

        {/* Hamburger menu for mobile */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-white focus:outline-none"
        >
          ☰
        </button>

        {/* Desktop Menu */}
        <ul className="hidden md:flex space-x-4 ml-10">
          <li>
            <Link
              to="/"
              className="px-4 py-2 rounded-md hover:bg-yellow-500 hover:text-black transition duration-300"
            >
              Home
            </Link>
          </li>
          <li>
            <Link
              to="/marketplace"
              className="px-4 py-2 rounded-md hover:bg-yellow-500 hover:text-black transition duration-300"
            >
              Marketplace
            </Link>
          </li>
          <li>
            <Link
              to="/booking"
              className="px-4 py-2 rounded-md hover:bg-yellow-500 hover:text-black transition duration-300"
            >
              Booking
            </Link>
          </li>
          <li>
            <Link
              to="/chatbot"
              className="px-4 py-2 rounded-md hover:bg-yellow-500 hover:text-black transition duration-300"
            >
              Chatbot
            </Link>
          </li>
          <li>
            <Link
              to="/maps"
              className="px-4 py-2 rounded-md hover:bg-yellow-500 hover:text-black transition duration-300"
            >
              Maps
            </Link>
          </li>
          <li>
            <Link
              to="/analytics"
              className="px-4 py-2 rounded-md hover:bg-yellow-500 hover:text-black transition duration-300"
            >
              Analytics
            </Link>
          </li>
        </ul>

        {/* Login Button (desktop only) */}
        <div className="hidden md:block ml-auto">
          <Link
            to="/login"
            className="px-4 py-2 bg-yellow-500 text-black font-bold rounded-lg shadow hover:bg-yellow-600 transition duration-300"
          >
            Login
          </Link>
        </div>
      </div>

      {/* Mobile Dropdown */}
      {isOpen && (
        <div className="md:hidden mt-2 space-y-2">
          <Link
            to="/"
            className="block px-4 py-2 bg-gray-700 rounded hover:bg-yellow-500 hover:text-black"
            onClick={() => setIsOpen(false)}
          >
            Home
          </Link>
          <Link
            to="/marketplace"
            className="block px-4 py-2 bg-gray-700 rounded hover:bg-yellow-500 hover:text-black"
            onClick={() => setIsOpen(false)}
          >
            Marketplace
          </Link>
          <Link
            to="/booking"
            className="block px-4 py-2 bg-gray-700 rounded hover:bg-yellow-500 hover:text-black"
            onClick={() => setIsOpen(false)}
          >
            Booking
          </Link>
          <Link
            to="/chatbot"
            className="block px-4 py-2 bg-gray-700 rounded hover:bg-yellow-500 hover:text-black"
            onClick={() => setIsOpen(false)}
          >
            Chatbot
          </Link>
          <Link
            to="/maps"
            className="block px-4 py-2 bg-gray-700 rounded hover:bg-yellow-500 hover:text-black"
            onClick={() => setIsOpen(false)}
          >
            Maps
          </Link>
          <Link
            to="/analytics"
            className="block px-4 py-2 bg-gray-700 rounded hover:bg-yellow-500 hover:text-black"
            onClick={() => setIsOpen(false)}
          >
            Analytics
          </Link>
          <Link
            to="/login"
            className="block px-4 py-2 bg-yellow-500 text-black font-bold rounded-lg shadow hover:bg-yellow-600"
            onClick={() => setIsOpen(false)}
          >
            Login
          </Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;