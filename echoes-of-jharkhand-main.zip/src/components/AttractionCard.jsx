import React from "react";

const AttractionCard = ({ image, title, description, link }) => {
  return (
    <div className="bg-white bg-opacity-90 shadow-lg rounded-lg overflow-hidden w-64 m-4">
      <img src={image} alt={title} className="h-40 w-full object-cover" />
      <div className="p-4">
        <h3 className="font-bold text-xl mb-2">{title}</h3>
        <p className="text-gray-700 mb-4">{description}</p>
        <a href={link} className="text-green-700 font-semibold">
          Read More
        </a>
      </div>
    </div>
  );
};

export default AttractionCard;
