import React from 'react';

const TripPlanner = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Trip Planner</h1>
      <p>This is the Trip Planner component. Here users can plan their trips to Jharkhand.</p>
    </div>
  );
};

export default TripPlanner;