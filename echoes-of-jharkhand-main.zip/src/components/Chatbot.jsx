import React, { useState } from "react";

function Chatbot() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Welcome to EchoesBot! I can guide you about Jharkhand's heritage, maps, and trip planning. How can I help you today?" },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;

    // Add user message
    setMessages((prev) => [...prev, { sender: "user", text: input }]);

    // Simple bot response logic (can be replaced with API or Rasa)
    let botReply = "Sorry, I didn't understand that. Can you rephrase?";
    const lowerInput = input.toLowerCase();
    if (lowerInput.includes("hi") || lowerInput.includes("hello")) {
      botReply = "Hello! How can I assist you with Jharkhand today?";
    } else if (lowerInput.includes("weather")) {
      botReply = "I can provide Jharkhand weather updates soon!";
    } else if (lowerInput.includes("temple") || lowerInput.includes("jagannath")) {
      botReply = "You can visit Jagannath Temple in Ranchi. I can guide you there on the map!";
    }

    setTimeout(() => {
      setMessages((prev) => [...prev, { sender: "bot", text: botReply }]);
    }, 500);

    setInput("");
  };

  return (
    <div
      className="fixed bottom-5 right-5 z-50"
      style={{
        width: "450px",
        height: "600px",
        borderRadius: "12px",
        boxShadow: "0 8px 24px rgba(0,0,0,0.3)",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {/* Header */}
      <div className="bg-emerald-700 text-white p-4 font-bold text-lg">
        EchoesBot
      </div>

      {/* Messages */}
      <div
        className="flex-1 p-4 overflow-y-auto bg-white"
        style={{ color: "black" }}
      >
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`mb-2 p-2 rounded ${
              msg.sender === "bot" ? "bg-gray-200 text-black" : "bg-emerald-700 text-white ml-auto"
            }`}
            style={{ maxWidth: "80%" }}
          >
            {msg.text}
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 bg-gray-100 flex">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 p-2 rounded border border-gray-300"
          style={{ color: "black" }}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
        />
        <button
          onClick={handleSend}
          className="ml-2 px-4 py-2 bg-emerald-700 text-white rounded hover:bg-emerald-800"
        >
          Send
        </button>
      </div>
    </div>
  );
}

export default Chatbot;