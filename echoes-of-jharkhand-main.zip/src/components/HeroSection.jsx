import React from "react";
import { Link } from "react-router-dom";

const HeroSection = () => {
  return (
    <section className="h-[70vh] flex flex-col justify-center items-center text-white text-center bg-black/30">
      <h1 className="text-5xl font-bold mb-4">Discover Jharkhand</h1>
      <p className="text-xl mb-6">Nature, Culture & Adventure Awaits</p>
      <div>
        <Link to="/trip-planner" className="bg-green-600 px-6 py-3 rounded mr-4">
          Plan My Trip
        </Link>
        <Link to="/explore" className="bg-white text-green-700 px-6 py-3 rounded">
          Explore Now
        </Link>
      </div>
    </section>
  );
};

export default HeroSection;
