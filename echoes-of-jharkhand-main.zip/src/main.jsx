import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import App from './App.jsx';
import './index.css';

// Import all pages
import Home from './pages/Home.jsx';
import Booking from './pages/Booking.jsx';
import Login from './pages/Login.jsx';
import Maps from './pages/Maps.jsx';
import Marketplace from './pages/Marketplace.jsx';
import Analytics from './pages/Analytics.jsx';
import ProducerPanel from './pages/ProducerPanel.jsx';
import UserMarketplace from './pages/UserMarketplace.jsx';
import TripPlanner from './components/TripPlanner.jsx';
import Chatbot from './components/Chatbot.jsx';

const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'booking',
        element: <Booking />,
      },
      {
        path: 'login',
        element: <Login />,
      },
      {
        path: 'maps',
        element: <Maps />,
      },
      {
        path: 'marketplace',
        element: <Marketplace />,
      },
      {
        path: 'analytics',
        element: <Analytics />,
      },
      {
        path: 'producer-panel',
        element: <ProducerPanel />,
      },
      {
        path: 'user-marketplace',
        element: <UserMarketplace />,
      },
      {
        path: 'trip-planner',
        element: <TripPlanner />,
      },
      {
        path: 'chatbot',
        element: <Chatbot />,
      },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>
);