import React, { useState } from "react";

const homestays = [
  {
    id: 1,
    name: "Tribal Homestay, Ranchi",
    price: 1200,
    img: "/images/homestay1.jpg",
    description: "Experience Jharkhand’s tribal culture with authentic home-cooked meals.",
  },
  {
    id: 2,
    name: "Eco Village, Netarhat",
    price: 1500,
    img: "/images/homestay2.jpg",
    description: "Stay in eco-friendly huts surrounded by forests and valleys.",
  },
];

const guides = [
  {
    id: 1,
    name: "Local Guide – Parasnath Hills",
    price: 800,
    img: "/images/guide1.jpg",
    description: "Experienced guide for temple visits and trekking.",
  },
  {
    id: 2,
    name: "Wildlife Guide – Betla National Park",
    price: 1000,
    img: "/images/guide2.jpg",
    description: "Specialist in jungle safari, wildlife photography and local culture.",
  },
];

function Booking() {
  const [bookings, setBookings] = useState([]);

  const handleBooking = (item) => {
    setBookings([...bookings, item]);
    alert(`✅ You booked: ${item.name}`);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto text-white">
      <h2 className="text-4xl font-bold text-center mb-8">🌿 Book Your Stay & Guides</h2>

      {/* Homestays Section */}
      <h3 className="text-2xl font-semibold mb-4">🏡 Homestays</h3>
      <div className="grid md:grid-cols-2 gap-6 mb-10">
        {homestays.map((stay) => (
          <div
            key={stay.id}
            className="bg-gray-800 rounded-lg shadow-lg p-4 flex flex-col items-center"
          >
            <img
              src={stay.img}
              alt={stay.name}
              className="w-full h-48 object-cover rounded-md mb-4"
            />
            <h4 className="text-xl font-bold">{stay.name}</h4>
            <p className="text-gray-300 mt-2">{stay.description}</p>
            <p className="text-yellow-400 font-bold mt-2">₹{stay.price} / night</p>
            <button
              className="mt-4 px-4 py-2 bg-yellow-500 text-black font-bold rounded hover:bg-yellow-600"
              onClick={() => handleBooking(stay)}
            >
              Book Now
            </button>
          </div>
        ))}
      </div>

      {/* Guides Section */}
      <h3 className="text-2xl font-semibold mb-4">🧭 Guides</h3>
      <div className="grid md:grid-cols-2 gap-6 mb-10">
        {guides.map((guide) => (
          <div
            key={guide.id}
            className="bg-gray-800 rounded-lg shadow-lg p-4 flex flex-col items-center"
          >
            <img
              src={guide.img}
              alt={guide.name}
              className="w-full h-48 object-cover rounded-md mb-4"
            />
            <h4 className="text-xl font-bold">{guide.name}</h4>
            <p className="text-gray-300 mt-2">{guide.description}</p>
            <p className="text-yellow-400 font-bold mt-2">₹{guide.price} / day</p>
            <button
              className="mt-4 px-4 py-2 bg-yellow-500 text-black font-bold rounded hover:bg-yellow-600"
              onClick={() => handleBooking(guide)}
            >
              Book Now
            </button>
          </div>
        ))}
      </div>

      {/* My Bookings */}
      <h3 className="text-2xl font-semibold mb-4">📖 My Bookings</h3>
      {bookings.length > 0 ? (
        <ul className="list-disc pl-6 text-gray-300">
          {bookings.map((b, idx) => (
            <li key={idx}>{b.name} ✅</li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-400">No bookings yet.</p>
      )}
    </div>
  );
}

export default Booking;
