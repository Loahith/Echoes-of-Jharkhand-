import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="page-container">
      <header className="text-center py-10 bg-gray-50 text-black">
        <h1 className="text-4xl font-bold">Welcome to Echoes of Jharkhand</h1>
        <p className="mt-2 text-lg">Explore the rich heritage and beauty of Jharkhand.</p>
      </header>

      <section className="my-10">
        <h2 className="text-3xl font-semibold text-center mb-6">Discover Jharkhand</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-4 border rounded shadow-md text-center">
            <h3 className="font-bold text-xl">Places to Visit</h3>
            <p className="mt-2">Learn about the stunning waterfalls, temples, and national parks.</p>
            <Link to="/maps" className="mt-4 inline-block bg-blue-500 text-white px-4 py-2 rounded">
              View Maps
            </Link>
          </div>
          <div className="p-4 border rounded shadow-md text-center">
            <h3 className="font-bold text-xl">Local Marketplace</h3>
            <p className="mt-2">Explore and buy traditional arts, crafts, and products.</p>
            <Link to="/marketplace" className="mt-4 inline-block bg-green-500 text-white px-4 py-2 rounded">
              Go to Marketplace
            </Link>
          </div>
          <div className="p-4 border rounded shadow-md text-center">
            <h3 className="font-bold text-xl">Book Your Trip</h3>
            <p className="mt-2">Find and book hotels, transport, and tour guides.</p>
            <Link to="/booking" className="mt-4 inline-block bg-purple-500 text-white px-4 py-2 rounded">
              Book Now
            </Link>
          </div>
        </div>
      </section>

      <footer className="text-center py-6 text-gray-600 border-t mt-10">
        <p>&copy; 2024 Echoes of Jharkhand. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Home;