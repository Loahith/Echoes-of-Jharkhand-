import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap, Circle } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Fix default marker icons
import iconRetinaUrl from "leaflet/dist/images/marker-icon-2x.png";
import iconUrl from "leaflet/dist/images/marker-icon.png";
import shadowUrl from "leaflet/dist/images/marker-shadow.png";
L.Icon.Default.mergeOptions({ iconRetinaUrl, iconUrl, shadowUrl });

// Tourist spots
const touristSpots = [
  { name: "Ranchi – Capital City", coords: [23.3441, 85.3096], peak: "Oct-Mar" },
  { name: "Jamshedpur – Industrial & Parks", coords: [23.7957, 86.4304], peak: "Oct-Mar" },
  { name: "Netarhat – Sunrise Point", coords: [23.7345, 84.3774], peak: "Sep-Feb" },
  { name: "Betla National Park", coords: [23.5178, 84.1673], peak: "Oct-Mar" },
  { name: "Parasnath Hills – Jain Temples", coords: [23.815, 86.5113], peak: "Oct-Mar" },
  { name: "Rajrappa – Chhinnamasta Temple", coords: [23.7736, 85.6164], peak: "Oct-Mar" },
  { name: "Hazaribagh Wildlife Sanctuary", coords: [23.991, 85.3616], peak: "Oct-Mar" },
  { name: "Bokaro – Steel City", coords: [23.6693, 86.1514], peak: "Oct-Mar" },
];

// Fly to selected spot
function FlyToSpot({ spot }) {
  const map = useMap();
  useEffect(() => {
    if (spot) {
      map.flyTo(spot.coords, 12, { duration: 1.5 });
    }
  }, [spot, map]);
  return null;
}

function Maps() {
  const [selectedSpot, setSelectedSpot] = useState(null);
  const [userLocation, setUserLocation] = useState(null);

  // Detect user location
  const handleShowLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
        () => alert("Please allow location access to use this feature.")
      );
    } else {
      alert("Geolocation not supported by your browser.");
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <h2 className="text-4xl font-bold text-center mb-6 text-white drop-shadow-lg">
        Explore Jharkhand – Tourist Map
      </h2>

      <div className="flex justify-end mb-4">
        <button
          className="px-4 py-2 rounded bg-gray-800 text-white hover:bg-gray-900"
          onClick={handleShowLocation}
        >
          Show My Location
        </button>
      </div>

      <div className="rounded-lg overflow-hidden shadow-lg border-2 border-emerald-700">
        <MapContainer
          center={[23.3441, 85.3096]}
          zoom={7}
          style={{ height: "600px", width: "100%" }}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="&copy; OpenStreetMap contributors"
          />

          {/* Tourist markers */}
          {touristSpots.map((spot, idx) => (
            <Marker key={idx} position={spot.coords}>
              <Popup>
                <strong>{spot.name}</strong>
                <br />
                Peak Time: {spot.peak}
              </Popup>
            </Marker>
          ))}

          {/* Peak areas as circles */}
          {touristSpots.map((spot, idx) => (
            <Circle
              key={`circle-${idx}`}   // ✅ fixed key here
              center={spot.coords}
              radius={3000}
              pathOptions={{ color: "gold", fillOpacity: 0.2 }}
            />
          ))}

          {/* User location */}
          {userLocation && (
            <Marker position={userLocation}>
              <Popup>You are here!</Popup>
            </Marker>
          )}

          <FlyToSpot spot={selectedSpot} />
        </MapContainer>
      </div>

      {/* Tourist spot buttons */}
      <div className="mt-6 flex flex-wrap gap-2 justify-center">
        {touristSpots.map((spot) => (
          <button
            key={spot.name}
            onClick={() => setSelectedSpot(spot)}
            className="px-3 py-1 rounded bg-yellow-400 text-black font-bold hover:bg-yellow-500 transition duration-300"
          >
            {spot.name}
          </button>
        ))}
      </div>

      {/* Trip Planner Section */}
      <div className="w-full mt-6 p-4 bg-white rounded shadow-lg">
        <h3 className="text-2xl font-bold mb-3 text-gray-800">Trip Planner</h3>
        <p className="text-gray-700 mb-2">
          Plan your visit by selecting destinations and checking routes.
        </p>
        <ul className="list-disc list-inside text-gray-700">
          {selectedSpot ? (
            <li>
              You selected: <strong>{selectedSpot.name}</strong> - Best Time to Visit: {selectedSpot.peak}
            </li>
          ) : (
            <li>Please click a tourist spot above to start planning your trip.</li>
          )}
        </ul>
      </div>
    </div>
  );
}

export default Maps;
