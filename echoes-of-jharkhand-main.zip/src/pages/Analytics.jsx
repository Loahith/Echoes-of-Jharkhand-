import React from "react";
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  ResponsiveContainer,
} from "recharts";

const Analytics = () => {
  // Sample data
  const visitorData = [
    { month: "Jan", visitors: 400 },
    { month: "Feb", visitors: 700 },
    { month: "Mar", visitors: 1000 },
    { month: "Apr", visitors: 1200 },
    { month: "May", visitors: 900 },
    { month: "Jun", visitors: 1500 },
	{ month: "Jul", visitors: 1300 },
    { month: "Aug", visitors: 1600 },
    { month: "Sep", visitors: 1700 },
  ];

  const bookingData = [
    { name: "Hotels", value: 45 },
    { name: "Transport", value: 25 },
    { name: "Guides", value: 20 },
    { name: "Others", value: 10 },
  ];

  const marketplaceData = [
    { item: "Handicrafts", sales: 300 },
    { item: "Textiles", sales: 200 },
    { item: "Jewelry", sales: 150 },
    { item: "Local Food", sales: 250 },
  ];

  const COLORS = ["#FFD700", "#FF6B6B", "#4ECDC4", "#1A535C"];

  // Summaries
  const totalVisitors = visitorData.reduce((acc, cur) => acc + cur.visitors, 0);
  const avgVisitors = Math.round(totalVisitors / visitorData.length);

  const topBooking = bookingData.reduce((a, b) => (a.value > b.value ? a : b));
  const topMarketplace = marketplaceData.reduce((a, b) =>
    a.sales > b.sales ? a : b
  );

  return (
    <div className="p-6">
      <h1 className="text-3xl font-extrabold text-gray-900 mb-6">
        📊 Tourism Analytics
      </h1>

      {/* Visitors Line Chart */}
      <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-bold mb-2">Monthly Visitor Statistics</h2>
        <p className="text-gray-600 mb-4">
          Total visitors in 6 months: <b>{totalVisitors}</b> <br />
          Average monthly visitors: <b>{avgVisitors}</b> <br />
          Peak month: <b>{visitorData.reduce((a, b) => (a.visitors > b.visitors ? a : b)).month}</b>
        </p>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={visitorData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="visitors"
              stroke="#FFD700"
              strokeWidth={3}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Bookings Pie Chart */}
      <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-bold mb-2">Booking Trends</h2>
        <p className="text-gray-600 mb-4">
          Most popular booking type: <b>{topBooking.name}</b> (
          {topBooking.value}%) <br />
          Categories covered: <b>{bookingData.length}</b>
        </p>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={bookingData}
              cx="50%"
              cy="50%"
              outerRadius={100}
              dataKey="value"
              label
            >
              {bookingData.map((entry, index) => (
                <Cell key={index} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Marketplace Bar Chart */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h2 className="text-xl font-bold mb-2">Marketplace Insights</h2>
        <p className="text-gray-600 mb-4">
          Best-selling product: <b>{topMarketplace.item}</b> (
          {topMarketplace.sales} units) <br />
          Total product categories: <b>{marketplaceData.length}</b>
        </p>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={marketplaceData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="item" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="sales" fill="#4ECDC4" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Analytics;