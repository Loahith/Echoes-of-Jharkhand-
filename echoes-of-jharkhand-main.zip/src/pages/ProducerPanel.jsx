import React from 'react';

const ProducerPanel = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Producer Panel</h1>
      <p>This is the panel for producers to manage their products, orders, and sales.</p>
    </div>
  );
};

export default ProducerPanel;