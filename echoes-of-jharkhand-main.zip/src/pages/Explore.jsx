import React from "react";
import Navbar from "../components/Navbar";

function Explore() {
  const places = [
    {
      name: "Betla National Park",
      image: "/images/betla.jpg",
      description: "Wildlife sanctuary in Jharkhand with tigers, elephants, and rich biodiversity.",
      bestTime: "Oct–Mar",
      hours: "6 AM – 6 PM",
      features: ["Safari rides", "Bird watching", "Forest trails"],
    },
    {
      name: "Dassam Falls",
      image: "/images/dassam-falls.jpg",
      description: "Beautiful waterfall surrounded by rocky cliffs.",
      bestTime: "Jul–Feb",
      hours: "8 AM – 5 PM",
      features: ["Photography", "Picnic", "Trekking nearby"],
    },
    // Add other places similarly
  ];

  return (
    <>
      <Navbar />
      <div className="app-content min-h-screen px-4 py-8">
        <h2 className="text-4xl font-bold text-yellow-400 mb-12 text-center text-overlay inline-block p-4">
          Explore Jharkhand 🌿
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {places.map((place, idx) => (
            <div key={idx} className="bg-gray-800 rounded-lg overflow-hidden shadow-lg hover:scale-105 transform transition duration-300">
              <img
                src={place.image}
                alt={place.name}
                width="500"
                height="350"
                style={{ objectFit: "cover" }}
              />
              <div className="p-4 text-left text-overlay">
                <h3 className="text-xl font-semibold text-yellow-400 mb-2">{place.name}</h3>
                <p className="text-gray-200 mb-2">{place.description}</p>
                <p className="text-gray-300 mb-1"><strong>Best Time:</strong> {place.bestTime}</p>
                <p className="text-gray-300 mb-2"><strong>Hours:</strong> {place.hours}</p>
                <ul className="list-disc list-inside text-gray-200">
                  {place.features.map((f, i) => <li key={i}>{f}</li>)}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Explore;
