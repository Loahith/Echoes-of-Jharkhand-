// src/pages/Marketplace.jsx
import React, { useState, useEffect } from "react";

function Marketplace() {
  const [products, setProducts] = useState([]);
  const [mode, setMode] = useState("user"); // "user" or "producer"
  const [newProduct, setNewProduct] = useState({
    name: "",
    description: "",
    price: "",
    image: "",
  });

  // Load products from localStorage (or defaults)
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("products"));
    if (saved && saved.length > 0) {
      setProducts(saved); // Load previously saved products
    } else {
      const defaultProducts = [
        {
          id: 1,
          name: "Tribal Necklace",
          description: "Beautiful handmade tribal necklace from Jharkhand.",
          price: "₹499",
          image: "/images/necklace.jpg",
          reviews: [],
        },
        {
          id: 2,
          name: "Bamboo Basket",
          description: "Eco-friendly handwoven bamboo basket.",
          price: "₹299",
          image: "/images/bamboo-basket.jpg",
          reviews: [],
        },
      ];
      setProducts(defaultProducts);
      localStorage.setItem("products", JSON.stringify(defaultProducts));
    }
  }, []);

  // Save to localStorage whenever products change
  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products));
  }, [products]);

  // Convert uploaded image to base64
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      setNewProduct({ ...newProduct, image: reader.result });
    };
    reader.readAsDataURL(file);
  };

  // Add a new product
  const handleAddProduct = (e) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price || !newProduct.image) {
      alert("Please fill in all required fields!");
      return;
    }
    const newItem = {
      id: Date.now(),
      ...newProduct,
      reviews: [],
    };
    const updatedProducts = [...products, newItem];
    setProducts(updatedProducts);
    localStorage.setItem("products", JSON.stringify(updatedProducts));
    setNewProduct({ name: "", description: "", price: "", image: "" });
  };

  // Delete a product
  const handleDeleteProduct = (id) => {
    const updated = products.filter((p) => p.id !== id);
    setProducts(updated);
    localStorage.setItem("products", JSON.stringify(updated));
  };

  // Add a review
  const handleAddReview = (id, reviewText) => {
    const updated = products.map((p) =>
      p.id === id ? { ...p, reviews: [...p.reviews, reviewText] } : p
    );
    setProducts(updated);
    localStorage.setItem("products", JSON.stringify(updated));
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h2 className="text-3xl font-bold text-center mb-6 text-white">
        🌿 Echoes of Jharkhand – Marketplace ({mode})
      </h2>

      {/* Mode Toggle */}
      <div className="flex justify-center mb-6">
        <button
          onClick={() => setMode("user")}
          className={`px-4 py-2 mx-2 rounded ${
            mode === "user" ? "bg-green-600" : "bg-gray-700"
          } text-white`}
        >
          User
        </button>
        <button
          onClick={() => setMode("producer")}
          className={`px-4 py-2 mx-2 rounded ${
            mode === "producer" ? "bg-green-600" : "bg-gray-700"
          } text-white`}
        >
          Producer
        </button>
      </div>

      {/* Producer Form */}
      {mode === "producer" && (
        <form
          onSubmit={handleAddProduct}
          className="bg-gray-800 p-4 rounded-lg mb-6"
        >
          <h3 className="text-xl text-white font-bold mb-3">
            Add New Product
          </h3>
          <input
            type="text"
            placeholder="Product Name"
            value={newProduct.name}
            onChange={(e) =>
              setNewProduct({ ...newProduct, name: e.target.value })
            }
            className="w-full mb-2 p-2 rounded text-black"
          />
          <textarea
            placeholder="Description"
            value={newProduct.description}
            onChange={(e) =>
              setNewProduct({ ...newProduct, description: e.target.value })
            }
            className="w-full mb-2 p-2 rounded text-black"
          />
          <input
            type="text"
            placeholder="Price (₹)"
            value={newProduct.price}
            onChange={(e) =>
              setNewProduct({ ...newProduct, price: e.target.value })
            }
            className="w-full mb-2 p-2 rounded text-black"
          />
          <input
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="w-full mb-2 p-2 rounded text-black"
          />
          <button
            type="submit"
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          >
            Add Product
          </button>
        </form>
      )}

      {/* Product List */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.length > 0 ? (
          products.map((product) => (
            <div
              key={product.id}
              className="bg-gray-900 text-white p-4 rounded-lg shadow-lg"
            >
              {product.image && (
                <img
                  src={product.image}
                  alt={product.name}
                  style={{ width: "100%", height: "auto" }}
                  className="rounded mb-3"
                />
              )}
              <h3 className="text-xl font-bold">{product.name}</h3>
              <p className="text-gray-300">{product.description}</p>
              <p className="mt-2 font-bold">{product.price}</p>

              {/* Delete button for producers */}
              {mode === "producer" && (
                <button
                  onClick={() => handleDeleteProduct(product.id)}
                  className="mt-2 bg-red-600 px-3 py-1 rounded hover:bg-red-700"
                >
                  Delete
                </button>
              )}

              {/* Reviews */}
              {mode === "user" && (
                <div className="mt-3">
                  <h4 className="font-bold">Reviews:</h4>
                  <ul className="text-sm text-gray-300">
                    {product.reviews.length > 0 ? (
                      product.reviews.map((r, i) => <li key={i}>– {r}</li>)
                    ) : (
                      <li>No reviews yet.</li>
                    )}
                  </ul>
                  <input
                    type="text"
                    placeholder="Write a review..."
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleAddReview(product.id, e.target.value);
                        e.target.value = "";
                      }
                    }}
                    className="w-full mt-2 p-2 rounded text-black"
                  />
                </div>
              )}
            </div>
          ))
        ) : (
          <p className="text-white">No products available.</p>
        )}
      </div>
    </div>
  );
}

export default Marketplace;
